package mx.niluxer.store;

public class Config {
    public static final String BASE_URL        = "https://10.74.134.10/~niluxer/wordpress/wp-json/wc/v2/";
    public static final String consumer_key    = "ck_51e68e6fe9199ba970877db693f6527db8d0deac";
    public static final String consumer_secret = "cs_c4cdcf7ce84828b3885ed23d28ff691b252fe71f";
}
