package mx.niluxer.store;

public class Config {
    public static final String BASE_URL        = "https://192.168.1.76:90/wordpress/wordpress/wp-json/wc/v2/";
    public static final String consumer_key    = "ck_9691c3810f423ffe7a972cfc45ff7f77499e8da6";
    public static final String consumer_secret = "cs_91a5da61568e0710ff369f262ff8f10f33a055e3";
}
